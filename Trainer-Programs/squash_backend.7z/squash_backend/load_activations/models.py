from django.db import models

class ActivationCode(models.Model):
    activation_id = models.AutoField(primary_key=True,unique=True)
    activation_code = models.CharField(max_length=10)
    code_distributed = models.BooleanField(default=False)
    code_used = models.BooleanField(default=False)

	
