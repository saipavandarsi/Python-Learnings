from django.http import HttpResponse
from load_activations.models import ActivationCode
from squash_backend.settings import NUMBER_OF_ACTIVATION_CODES

import uuid

def save_activation_code(request):
    for i in xrange(NUMBER_OF_ACTIVATION_CODES):
        activation_code = str(uuid.uuid4().get_hex().upper()[0:10])
        obj = ActivationCode(
            activation_code = activation_code)
        obj.save()
    return HttpResponse("data inserted")
