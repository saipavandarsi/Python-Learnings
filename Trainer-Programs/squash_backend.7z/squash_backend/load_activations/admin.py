from django.contrib import admin
from load_activations.models import ActivationCode

admin.site.register(ActivationCode)