from random import random, randint
from rest_framework import serializers
from .models import CoostaUser

class CoostaUserSerializer(serializers.ModelSerializer):

    class Meta:
        model = CoostaUser
        fields = ('userid', 'username', 'firstname', 'lastname', 'pincode', 'contact', 'email', 'password')



