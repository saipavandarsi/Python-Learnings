from rest_framework import status
from rest_framework import permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response

from django.db.models import Q
from django.core.mail import send_mail
from django.shortcuts import render_to_response

from .models import CoostaUser
from .serializers import CoostaUserSerializer
from load_activations.models import ActivationCode


@api_view(['GET', 'POST'])
@permission_classes((permissions.AllowAny,))
def create_user(request):
    """
    Create a new user.
    """
    if request.method == 'GET':
        coosta_users = CoostaUser.objects.all()
        serializer = CoostaUserSerializer(coosta_users, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = CoostaUserSerializer(data=request.data)
        if serializer.is_valid():
            email = request.data['email']
            activation_code = request.data['activation_code']
            serializer.save()
            generate_email(email)
            user_results = CoostaUser.objects.filter(Q(email=email))
            activation_code_results = ActivationCode.objects.filter(Q(activation_code=activation_code))
            if activation_code_results:
                for rec in activation_code_results:
                    rec.code_distributed = True
                    rec.save()
            if user_results:
                for rec in user_results:
                    rec.activation_code = activation_code_results[0]
                    rec.save()
            serialized_data = serializer.data
            serialized_data['activation_code'] = activation_code
            return Response(serialized_data, status=status.HTTP_201_CREATED)
        else:
            return Response(
                serializer.errors, status=status.HTTP_400_BAD_REQUEST)
               
def generate_email(email):
    """ """
    send_mail('Welcome to Hubree', 'Welcome to Hubree, Real estate app, Plick below link to activate', 'hubreeh@gmail.com',
    [email], fail_silently=False)
    
