from django.contrib import admin
from models import CoostaUser

admin.site.register(CoostaUser)