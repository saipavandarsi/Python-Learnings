import uuid
from datetime import datetime 
from django.db import models
from load_activations.models import ActivationCode

class CoostaUser(models.Model):
    userid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    username = models.TextField()
    firstname = models.TextField()
    lastname = models.TextField()
    contact = models.TextField()
    pincode = models.TextField()
    password = models.TextField()
    activation_code = models.ForeignKey(ActivationCode, blank=True, null=True)
    email = models.EmailField(max_length=70, blank=True, null=True, unique=True)
