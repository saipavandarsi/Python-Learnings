from rest_framework import status
from rest_framework import permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response

from django.db.models import Q
from django.shortcuts import render_to_response

from load_activations.models import ActivationCode

@api_view(['GET'])
@permission_classes((permissions.AllowAny,))
def get_activation_code(request):
    """
    Create a new user.
    """
    if request.method == 'GET':
        activation_code_obj = ActivationCode.objects.filter(Q(code_distributed=False))
        activation_code = activation_code_obj[0].activation_code
        code_distributed = activation_code_obj[0].code_distributed
        serialized_data = {}
        serialized_data['activation_code'] = activation_code
        serialized_data['code_distributed'] = code_distributed
        return Response(serialized_data)
