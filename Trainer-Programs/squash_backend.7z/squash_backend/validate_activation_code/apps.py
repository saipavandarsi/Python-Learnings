from __future__ import unicode_literals

from django.apps import AppConfig


class ValidateActivationCodeConfig(AppConfig):
    name = 'validate_activation_code'
